import React from "react";

const Copyright = () => {
	return (
		<p>
			Copyright &copy; 2021 <span className="text-green">John Doe</span>. All
			rights reserved
		</p>
	);
};

export default Copyright;
