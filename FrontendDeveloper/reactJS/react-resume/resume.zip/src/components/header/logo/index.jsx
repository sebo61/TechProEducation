import React from 'react'

const Logo = () => {
  return (
    <h1>John Doe</h1>
  )
}

export default Logo