import React from "react";

const WhoAmI = () => {
	return (
		<>
			<h3>
				I'm <span className="text-green">John Doe</span>, a Web
				Developer
			</h3>
			<p>
				I help you build brand for your business at an affordable price.
				Thousands of clients have procured exceptional results while
				working with our dedicated team. when an unknown printer took a
				galley of type and scrambled it to make a type specimen book.
			</p>

			<p>
				Delivering work within time and budget which meets client`s
				requirements is our moto. Lorem Ipsum has been the industry's
				standard dummy text ever when an unknown printer took a galley.
			</p>
		</>
	);
};

export default WhoAmI;
